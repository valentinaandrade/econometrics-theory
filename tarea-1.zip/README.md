#  Teoria Econometrica I

Repositorio que contiene códigos para el ramo de Teoria Econometrica I, cátedra del Magister de Economía UC dictada por el profesor Raimundo Soto. 